package net.skhu.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import net.skhu.dto.User;

public interface UserRepository extends MongoRepository<User, String> {
	Optional<User> findByUserName(String userName); // 로그인용
}
