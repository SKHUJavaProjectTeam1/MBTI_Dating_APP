package net.skhu.gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

public class MBTILoginSignup extends JFrame {

	// ====== 서버 엔드포인트 ======
	private static final String BASE = "http://localhost:8080/api";
	private static final String LOGIN_URL = BASE + "/users/login";
	private static final String SIGNUP_URL = BASE + "/users";

	// 로그인 성공 시 저장할 토큰(필요 시 활용)
	private static String token;

	// 색상
	private final Color color1 = new Color(255, 189, 189);// 분홍
	private final Color color2 = new Color(189, 255, 243);// 파랑
	private final Color color3 = new Color(213, 201, 255);// 보라

	// 왼쪽 버튼들
	private final JButton sideLogin = new JButton("로그인");
	private final JButton sideSignup = new JButton("회원가입");

	// 오른쪽 카드 영역
	private final JPanel contentCards = new JPanel(new CardLayout());
	private static final String CARD_LOGIN = "CARD_LOGIN";
	private static final String CARD_SIGNUP = "CARD_SIGNUP";

	// 로그인/회원가입 패널을 필드로 보관
	private final LoginContent loginContent = new LoginContent();
	private final SignupContent signupContent = new SignupContent();

	public MBTILoginSignup() {
		super("MBTI MATCH - Login / Signup");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(980, 620);
		setLocationRelativeTo(null);
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception ignored) {
		}

		setLayout(new BorderLayout());
		add(buildLeftSidebar(), BorderLayout.WEST);

		contentCards.add(loginContent, CARD_LOGIN);
		contentCards.add(signupContent, CARD_SIGNUP);
		add(contentCards, BorderLayout.CENTER);

		showCard(CARD_LOGIN);

		sideLogin.addActionListener(e -> showCard(CARD_LOGIN));
		sideSignup.addActionListener(e -> showCard(CARD_SIGNUP));
	}

	private void showCard(String key) {
		((CardLayout) contentCards.getLayout()).show(contentCards, key);
	}

	// =============== 왼쪽 사이드바 ===============
	private JComponent buildLeftSidebar() {
		JPanel left = new JPanel() {
			@Override
			protected void paintComponent(Graphics g) {
				super.paintComponent(g);
				Graphics2D g2d = (Graphics2D) g;
				int width = getWidth();
				int height = getHeight();
				GradientPaint gp = new GradientPaint(0, 0, color1, 0, height, color2);
				g2d.setPaint(gp);
				g2d.fillRect(0, 0, width, height);
			}
		};

		left.setPreferredSize(new Dimension(180, 0));
		left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
		left.setBorder(new CompoundBorder(new MatteBorder(0, 0, 0, 1, new Color(210, 210, 210)),
				new EmptyBorder(20, 16, 20, 16)));

		styleOval(sideLogin);
		styleOval(sideSignup);
		sideLogin.setBackground(color3);
		sideSignup.setBackground(color3);

		left.add(Box.createVerticalGlue());
		left.add(sideLogin);
		left.add(Box.createVerticalStrut(12));
		left.add(sideSignup);
		left.add(Box.createVerticalGlue());
		return left;
	}

	// =============== 오른쪽: 로그인 카드 ===============
	class LoginContent extends JPanel {
		private final JTextField tfId = new JTextField(20);
		private final JPasswordField tfPw = new JPasswordField(20);
		private final JButton btnLogin = new JButton("로그인하기");

		// 회원가입 후 로그인 폼에 값 세팅하는 헬퍼
		void presetForLogin(String id) {
			tfId.setText(id != null ? id : "");
			tfPw.setText("");
			tfId.requestFocusInWindow();
		}

		LoginContent() {

			setLayout(new GridBagLayout());
			setBorder(new EmptyBorder(0, 40, 0, 40));
			setBackground(new Color(250, 250, 250));

			GridBagConstraints gc = new GridBagConstraints();
			gc.insets = new Insets(10, 10, 10, 10);
			gc.gridx = 0;
			gc.gridy = 0;
			gc.gridwidth = 2;
			gc.anchor = GridBagConstraints.CENTER;

			JLabel title = new JLabel("LOGIN");
			title.setFont(title.getFont().deriveFont(Font.BOLD, 28f));
			add(title, gc);

			gc.gridy++;
			gc.fill = GridBagConstraints.HORIZONTAL;
			tfId.setPreferredSize(new Dimension(420, 40));
			tfId.setBorder(inputBorder());
			tfId.setToolTipText("아이디");
			add(tfId, gc);

			gc.gridy++;
			tfPw.setPreferredSize(new Dimension(420, 40));
			tfPw.setBorder(inputBorder());
			tfPw.setToolTipText("비밀번호");
			add(tfPw, gc);

			gc.gridy++;
			gc.gridwidth = 1;
			gc.fill = GridBagConstraints.NONE;
			gc.anchor = GridBagConstraints.EAST;
			styleSmall(btnLogin);
			btnLogin.setBackground(color1);
			add(btnLogin, gc);

			// 실제 로그인 동작
			btnLogin.addActionListener(e -> {
				String id = tfId.getText().trim();
				String pw = new String(tfPw.getPassword());
				if (id.isEmpty() || pw.isEmpty()) {
					JOptionPane.showMessageDialog(this, "ID와 PW를 입력하세요.");
					return;
				}

				// 컨트롤러는 userName, pwd 를 받음
				String json = "{\"userName\":\"" + escape(id) + "\",\"pwd\":\"" + escape(pw) + "\"}";

				try {
					HttpResult res = sendJsonPost(LOGIN_URL, json);
					if (res.isOk()) {
						// 지금은 서버가 User 객체(JSON)를 반환함. JWT가 아니라서 token 저장은 선택.
						token = ""; // JWT 도입 전이므로 비워둠(원하면 res.body 파싱해서 user 정보 표시)
						JOptionPane.showMessageDialog(this, "로그인 성공!\n");

						new MBTIHome().setVisible(true);
						SwingUtilities.getWindowAncestor(this).dispose();
					} else {
						JOptionPane.showMessageDialog(this, "로그인 실패 (" + res.code + ")\n");
					}
				} catch (java.net.ConnectException ce) {
					JOptionPane.showMessageDialog(this,
							"서버에 연결할 수 없습니다.\n- 서버가 실행 중인지\n- 주소/포트가 맞는지(8080)\n확인하세요.\n\n" + ce.getMessage());
				} catch (java.net.SocketTimeoutException te) {
					JOptionPane.showMessageDialog(this, "서버 응답 시간 초과: " + te.getMessage());
				} catch (Exception ex) {
					ex.printStackTrace();
					JOptionPane.showMessageDialog(this, "로그인 중 오류: " + ex.getMessage());
				}
			});

		}
	}

	// =============== 오른쪽: 회원가입 카드 ===============
	class SignupContent extends JPanel {
		private final JComboBox<String> cbMBTI = new JComboBox<>(MBTI_ALL);
		private final JTextField tfId2 = new JTextField(18); // 추가: 아이디
		private final JPasswordField tfPw2 = new JPasswordField(18); // 추가: 비밀번호
		private final JTextField tfName = new JTextField(18);
		private final JRadioButton rbF = new JRadioButton("여");
		private final JRadioButton rbM = new JRadioButton("남");
		private final JRadioButton rbO = new JRadioButton("기타");
		private final JSpinner spAge = new JSpinner(new SpinnerNumberModel(20, 18, 80, 1));
		private final JTextField tfRegion = new JTextField(18);
		private final JButton btnSubmit = new JButton("가입하기") {
			@Override
			protected void paintComponent(Graphics g) {
				Graphics2D g2 = (Graphics2D) g.create();
				GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
				g2.setPaint(gp);
				g2.fillRect(0, 0, getWidth(), getHeight());
				g2.dispose();
				super.paintComponent(g);
			}
		};

		SignupContent() {
			setLayout(new BorderLayout());
			setBackground(new Color(250, 250, 250));
			setBorder(new EmptyBorder(0, 32, 0, 32));

			JLabel title = new JLabel("회원가입");
			title.setBorder(new EmptyBorder(20, 0, 16, 0));
			title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));
			title.setHorizontalAlignment(SwingConstants.LEFT);
			add(title, BorderLayout.NORTH);

			JPanel form = new JPanel();
			form.setOpaque(false);
			form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
			form.setBorder(new EmptyBorder(8, 40, 8, 40));

			JLabel avatar = avatarLabel("images/default_profile.png", 72);
			JPanel avatarWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
			avatarWrap.setOpaque(false);
			avatarWrap.add(avatar);
			form.add(avatarWrap);
			form.add(Box.createVerticalStrut(12));

			// 아이디/비밀번호 (추가)
			tfId2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
			tfId2.setBorder(inputBorder());
			tfId2.setToolTipText("아이디");
			form.add(row("아이디", tfId2));

			tfPw2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
			tfPw2.setBorder(inputBorder());
			tfPw2.setToolTipText("비밀번호");
			form.add(row("비밀번호", tfPw2));

			// MBTI
			cbMBTI.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
			cbMBTI.setBorder(inputBorder());
			form.add(row("MBTI", cbMBTI));

			// 이름
			tfName.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
			tfName.setBorder(inputBorder());
			form.add(row("이름", tfName));

			// 성별 + 나이
			ButtonGroup g = new ButtonGroup();
			g.add(rbF);
			g.add(rbM);
			g.add(rbO);
			rbF.setOpaque(false);
			rbM.setOpaque(false);
			rbO.setOpaque(false);

			JPanel genderAge = new JPanel();
			genderAge.setOpaque(false);
			genderAge.setLayout(new BoxLayout(genderAge, BoxLayout.X_AXIS));
			genderAge.add(rbF);
			genderAge.add(Box.createHorizontalStrut(8));
			genderAge.add(rbM);
			genderAge.add(Box.createHorizontalStrut(8));
			genderAge.add(rbO);
			genderAge.add(Box.createHorizontalStrut(16));
			genderAge.add(new JLabel("나이 "));
			spAge.setMaximumSize(new Dimension(80, 32));
			genderAge.add(spAge);
			form.add(row("성별", genderAge));

			// 지역
			tfRegion.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
			tfRegion.setBorder(inputBorder());
			form.add(row("지역", tfRegion));

			// 가입하기 버튼
			JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 16));
			btnWrap.setOpaque(false);
			styleOval(btnSubmit);
			btnSubmit.setOpaque(false);
			btnWrap.add(btnSubmit);
			form.add(Box.createVerticalStrut(8));
			form.add(btnWrap);

			add(form, BorderLayout.CENTER);

			// 실제 회원가입 동작
			btnSubmit.addActionListener(e -> {
				String id = tfId2.getText().trim(); // => userName
				String pw = new String(tfPw2.getPassword()); // => pwd
				String mbti = (String) cbMBTI.getSelectedItem(); // "ENTP" 등 4글자
				// 소문자 gender ("f","m","o")로 보냄
				String gender = rbF.isSelected() ? "f" : rbM.isSelected() ? "m" : rbO.isSelected() ? "o" : "";
				int age = (Integer) spAge.getValue();

				// 현재 서버는 name/region을 받지 않는다 → 해당 필드는 검증 제외
				if (id.isEmpty() || pw.isEmpty()) {
					JOptionPane.showMessageDialog(this, "아이디/비밀번호를 입력하세요.");
					return;
				}
				if (gender.isEmpty()) {
					JOptionPane.showMessageDialog(this, "성별을 선택하세요.");
					return;
				}
				if (mbti == null || mbti.length() != 4) {
					JOptionPane.showMessageDialog(this, "MBTI 4글자를 선택하세요.");
					return;
				}

				String signupJson = new StringBuilder().append("{").append("\"userName\":\"").append(escape(id))
						.append("\",").append("\"pwd\":\"").append(escape(pw)).append("\",").append("\"gender\":\"")
						.append(escape(gender)).append("\",").append("\"age\":").append(age).append(",")
						.append("\"mbti\":\"").append(escape(mbti)).append("\"").append("}").toString();

				try {
				    HttpResult res = sendJsonPost(SIGNUP_URL, signupJson);
				    if (res.isOk()) {
				        // ✅ 성공 토스트
				        JOptionPane.showMessageDialog(this, "회원가입 성공! 로그인 화면으로 이동합니다.");

				        // ✅ 로그인 카드로 전환
				        MBTILoginSignup.this.showCard(CARD_LOGIN);

				        // ✅ 로그인 폼에 방금 가입한 아이디 채우고 비번은 비우기
				        loginContent.presetForLogin(id);

				        // ✅ (선택) 회원가입 폼 초기화
				        tfId2.setText("");
				        tfPw2.setText("");
				        tfName.setText("");
				        tfRegion.setText("");
				        rbF.setSelected(false);
				        rbM.setSelected(false);
				        rbO.setSelected(false);
				        spAge.setValue(20);
				        cbMBTI.setSelectedIndex(0);

				    } else {
				        JOptionPane.showMessageDialog(this, "회원가입 실패 (" + res.code + ")\n");
				    }
				} catch (java.net.ConnectException ce) {
				    JOptionPane.showMessageDialog(this,
				        "서버에 연결할 수 없습니다.\n- 서버 실행/포트(8080) 확인\n\n" + ce.getMessage());
				} catch (java.net.SocketTimeoutException te) {
				    JOptionPane.showMessageDialog(this, "서버 응답 시간 초과: " + te.getMessage());
				} catch (Exception ex) {
				    ex.printStackTrace();
				    JOptionPane.showMessageDialog(this, "회원가입 중 오류: " + ex.getMessage());
				}

			});

		}

		private JPanel row(String label, JComponent field) {
			JPanel p = new JPanel();
			p.setOpaque(false);
			p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
			JLabel l = new JLabel(label + "  |  ");
			l.setPreferredSize(new Dimension(72, 28));
			p.add(l);
			p.add(Box.createHorizontalStrut(6));
			p.add(field);
			p.add(Box.createVerticalStrut(8));
			p.setBorder(new EmptyBorder(6, 0, 6, 0));
			return p;
		}
	}

	// =============== 공통 스타일/헬퍼 ===============
	private void styleOval(JButton b) {
		b.setFocusPainted(false);
		b.setContentAreaFilled(false);
		b.setOpaque(true);
		b.setBackground(Color.WHITE);
		b.setBorder(
				new CompoundBorder(new LineBorder(new Color(200, 200, 200), 1, true), new EmptyBorder(10, 18, 10, 18)));
		b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	private void styleSmall(JButton b) {
		b.setFocusPainted(false);
		b.setContentAreaFilled(false);
		b.setOpaque(true);
		b.setBackground(Color.WHITE);
		b.setBorder(
				new CompoundBorder(new LineBorder(new Color(190, 190, 190), 1, true), new EmptyBorder(6, 10, 6, 10)));
		b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	private Border inputBorder() {
		return new CompoundBorder(new LineBorder(new Color(200, 200, 200), 1, true), new EmptyBorder(8, 10, 8, 10));
	}

	private JLabel avatarLabel(String pathOrClasspath, int size) {
		Image img;
		java.net.URL url = getClass().getResource(pathOrClasspath);
		if (url != null)
			img = new ImageIcon(url).getImage();
		else
			img = new ImageIcon(pathOrClasspath).getImage();
		Image scaled = img.getScaledInstance(size, size, Image.SCALE_SMOOTH);
		JLabel label = new JLabel(new ImageIcon(scaled));
		label.setPreferredSize(new Dimension(size, size));
		label.setBorder(
				new CompoundBorder(new LineBorder(new Color(180, 180, 180), 1, true), new EmptyBorder(2, 2, 2, 2)));
		return label;
	}

	// MBTI 목록
	private static final String[] MBTI_ALL = { "INTJ", "INTP", "INFJ", "INFP", "ISTJ", "ISFJ", "ISTP", "ISFP", "ENTJ",
			"ENTP", "ENFJ", "ENFP", "ESTJ", "ESFJ", "ESTP", "ESFP" };

	// =============== HTTP 공통 유틸 ===============
	private static class HttpResult {
		final int code;
		final String body;

		HttpResult(int code, String body) {
			this.code = code;
			this.body = body;
		}

		boolean isOk() {
			return code >= 200 && code < 300;
		}
	}

	private static HttpResult sendJsonPost(String url, String json) throws Exception {
		HttpURLConnection conn = null;
		try {
			URL u = new URL(url);
			conn = (HttpURLConnection) u.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			conn.setRequestProperty("Accept", "application/json, text/plain, */*");
			// 필요시 토큰 전송 (로그인 이후 API라면)
			if (token != null && !token.isEmpty()) {
				conn.setRequestProperty("Authorization", "Bearer " + token);
			}
			conn.setConnectTimeout(8000);
			conn.setReadTimeout(8000);
			conn.setDoOutput(true);

			try (OutputStream os = conn.getOutputStream()) {
				byte[] input = json.getBytes(StandardCharsets.UTF_8);
				os.write(input);
			}

			int code = conn.getResponseCode();
			String body = readAll(code >= 400 ? conn.getErrorStream() : conn.getInputStream());
			return new HttpResult(code, body);
		} finally {
			if (conn != null)
				conn.disconnect();
		}
	}

	private static String readAll(InputStream is) throws Exception {
		if (is == null)
			return "";
		try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = br.readLine()) != null)
				sb.append(line).append('\n');
			return sb.toString().trim();
		}
	}

	private static String escape(String s) {
		// 아주 단순한 JSON 이스케이프 (필요 시 라이브러리 사용 권장)
		return s.replace("\\", "\\\\").replace("\"", "\\\"");
	}

	private static String trimLong(String s) {
		if (s == null)
			return "";
		return s.length() > 500 ? s.substring(0, 500) + " ..." : s;
	}

	// 실행 진입점
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new MBTILoginSignup().setVisible(true));
	}
}
