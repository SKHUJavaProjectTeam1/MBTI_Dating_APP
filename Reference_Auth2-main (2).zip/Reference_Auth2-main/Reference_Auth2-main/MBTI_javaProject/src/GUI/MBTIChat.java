package GUI;

import javax.swing.*;
import java.awt.*;

public class MBTIChat extends JFrame{
	
	private final Color color1 = new Color(255, 189, 189);//분횽색
	private final Color color2 = new Color(189, 255, 243);//파랑색
	private final Color color3 = new Color(213, 201, 255);//보라색
	
	private JLabel topNameLabel;
    private JPanel topBox;
	
	public MBTIChat(){
		setTitle("채팅방");
        setSize(1200, 760);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 왼쪽 패널
        JPanel leftPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, color1,0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        leftPanel.setPreferredSize(new Dimension(250, 760));
        leftPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 20)); // 가운데 정렬, 위 아래 여백
        add(leftPanel, BorderLayout.WEST);
        
        // 1. 위쪽 제목
        JLabel titleLabel = new JLabel("채팅방");
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // 가운데 정렬
        titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 30));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); // 위/아래 여백
        leftPanel.add(titleLabel);    

        // 채팅방 목록 패널
        JPanel chatListPanel = new JPanel();
        chatListPanel.setPreferredSize(new Dimension(200, 500));
        chatListPanel.setBackground(color3);
        chatListPanel.setLayout(new BoxLayout(chatListPanel, BoxLayout.Y_AXIS));
        chatListPanel.setAlignmentX(Component.CENTER_ALIGNMENT); // 가운데 정렬
        leftPanel.add(chatListPanel);
        
        // 상단 민트색 패널
        JPanel topBox = new JPanel();
        topBox.setBackground(color2);
        topBox.setPreferredSize(new Dimension(200, 60));
        
        //민트색 사진 부분
        ImageIcon userIcon = new ImageIcon("images/default_profile.png");
        Image img = userIcon.getImage();
        Image scaledImg = img.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImg);
        
        //사진 크기 조정
        JLabel iconLabel = new JLabel(scaledIcon);
        iconLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        topBox.add(iconLabel, BorderLayout.WEST);
        
        //민트색 영역에서 사진 위치 왼쪽 끝으로
        topBox = new JPanel(new BorderLayout());
        topBox.setBackground(color2);
        topBox.setPreferredSize(new Dimension(200, 60));
        topBox.add(iconLabel, BorderLayout.WEST);

        // 중앙 이름 JLabel
        topNameLabel = new JLabel("aa"+" 님");
        topNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        topNameLabel.setFont(new Font("맑은 고딕", Font.BOLD, 18));
        topBox.add(topNameLabel, BorderLayout.CENTER);
        
        //민트색 위치 정하는 부분
        JPanel mintContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        mintContainer.setOpaque(false);
        mintContainer.add(topBox);
        
        // 채팅방 예시 데이터
        String[] users = {"aa님", "bb님", "cc님"};
        for (String user : users) {
        	final JLabel topNameLabel = new JLabel("");
        	
            JPanel chatRoom = new JPanel(){
    			@Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);//부모 클레스의 paintComponent 호출
                    
                    g.setColor(new Color(145, 78, 78));
                    
                    //패널의 가로줄
                    int y = getHeight() - 1;
                    //아래 부분만 선 그리기(왼쪽 끝(0, y)에서 오른쪽 끝까지(getWidth(), y))
                    g.drawLine(0, y, getWidth(), y);
                }
    		};
            chatRoom.setMaximumSize(new Dimension(180, 40)); // 패널 크기 제한
            chatRoom.setBackground(color3);
            chatRoom.setLayout(new BorderLayout());
            
            JLabel nameLabel = new JLabel(user);
            
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 5));
            buttonPanel.setOpaque(false);
            JButton enterButton = new JButton("입장");
            enterButton.setBackground(new Color(242, 227, 143));
            buttonPanel.add(enterButton);
            
            enterButton.addActionListener(e -> {
                topNameLabel.setText(user); // 클릭한 사용자의 이름으로 갱신
            });
            
            buttonPanel.add(enterButton);
            chatRoom.add(nameLabel, BorderLayout.WEST);
            chatRoom.add(buttonPanel, BorderLayout.EAST);

            chatListPanel.add(chatRoom);
            chatListPanel.add(Box.createRigidArea(new Dimension(0, 10))); // 각 채팅방 사이 여백
        }

        // 왼쪽 패널에 채팅 목록 추가
        leftPanel.add(chatListPanel);
        
        // 오른쪽 영역
        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // 전체 여백
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS)); // 세로 배치
        add(rightPanel, BorderLayout.CENTER);
        
        //메시지 영역
        JPanel mainBox = new JPanel();
        mainBox.setBackground(new Color(255, 218, 218));
        mainBox.setLayout(new BoxLayout(mainBox, BoxLayout.Y_AXIS));

        JPanel otherMsgPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        otherMsgPanel.setOpaque(false);
        JLabel otherMsg = new JLabel("안녕하세요!");
        otherMsg.setOpaque(true);
        otherMsg.setBackground(color1);
        otherMsg.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        otherMsgPanel.add(otherMsg);
        otherMsgPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        mainBox.add(otherMsgPanel);
        mainBox.add(Box.createVerticalStrut(8));

        JPanel myMsgPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        myMsgPanel.setOpaque(false);
        JLabel myMsg = new JLabel("안녕하세요! 저는 사용자입니다.");
        myMsg.setOpaque(true);
        myMsg.setBackground(new Color(200,255,230));
        myMsg.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        myMsgPanel.add(myMsg);
        myMsgPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        mainBox.add(myMsgPanel);
        mainBox.add(Box.createVerticalStrut(8));
       
        // 하단 회색 바
        JPanel bottomBox = new JPanel();
        bottomBox.setBackground(new Color(230, 230, 230));
        bottomBox.setLayout(new BoxLayout(bottomBox, BoxLayout.X_AXIS));
        bottomBox.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));

        // bottomBox 높이 고정
        bottomBox.setPreferredSize(new Dimension(0, 60));
        bottomBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        bottomBox.setMinimumSize(new Dimension(0, 60));
        
        // 연필 이미지
        ImageIcon icon = new ImageIcon("images/pencil.png"); // 이미지 경로
        Image pencil = icon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH); // 크기 조절
        ImageIcon pencilIcon = new ImageIcon(pencil);

        // 왼쪽 이미지
        JLabel leftIconLabel = new JLabel(pencilIcon);
        leftIconLabel.setPreferredSize(new Dimension(50, 50));

        bottomBox.add(leftIconLabel);
        bottomBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // 중앙 텍스트 입력창
        JTextField textField = new JTextField();
        textField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        textField.setOpaque(false);
        textField.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.black));
        bottomBox.add(textField);
        bottomBox.add(Box.createRigidArea(new Dimension(5,0))); // 텍스트와 오른쪽 버튼 사이 간격

        // 전송버튼 이미지
        ImageIcon sendIcon = new ImageIcon("images/submit.png");
        Image sub = sendIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        ImageIcon subIcon = new ImageIcon(sub);
        
        // 오른쪽 버튼
        JButton rightButton = new JButton(subIcon);
        rightButton.setPreferredSize(new Dimension(50,50));
        rightButton.setMaximumSize(new Dimension(50,50));
        rightButton.setFocusPainted(false);
        rightButton.setBackground(Color.white);

        // 클릭 시 메시지 전송 기능
        rightButton.addActionListener(e -> {
            String msg = textField.getText().trim();
            if (!msg.isEmpty()) {
                // 메시지를 mainBox에 추가
                JPanel myMsgSubPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                myMsgSubPanel.setOpaque(false);

                JLabel myMsgSub = new JLabel(msg);
                myMsgSub.setOpaque(true);
                myMsgSub.setBackground(new Color(200,255,230));
                myMsgSub.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
                myMsgSubPanel.add(myMsgSub);
                myMsgSubPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

                mainBox.add(myMsgSubPanel);
                mainBox.add(Box.createVerticalStrut(8));

                mainBox.revalidate();
                mainBox.repaint();

                textField.setText(""); // 입력창 초기화
            }
        });

        // bottomBox에 추가
        bottomBox.add(rightButton);

        // rightPanel 하단에 추가
        rightPanel.add(bottomBox, BorderLayout.SOUTH);


 
        // 중앙 배치
        JPanel centerArea = new JPanel();
        centerArea.setLayout(new BorderLayout());
        centerArea.add(mainBox, BorderLayout.CENTER);
        centerArea.add(bottomBox, BorderLayout.SOUTH);
        
        // 상단 민트 영역 위치
        topBox.setPreferredSize(new Dimension(200, 60));
        JPanel topContainer = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topContainer.setOpaque(false);
        topContainer.add(topBox);
        rightPanel.add(topContainer, BorderLayout.NORTH);
        
        JPanel topGap = new JPanel();
        topGap.setOpaque(false); // 투명
        topGap.setPreferredSize(new Dimension(800, 10)); // 10px 간격
        rightPanel.add(topGap, BorderLayout.AFTER_LAST_LINE);

        // 메시지 영역 위치
        mainBox.setPreferredSize(new Dimension(1000, 520));
        mainBox.setMinimumSize(new Dimension(1000, 520));
        mainBox.setMaximumSize(new Dimension(1000, 520));
        rightPanel.add(mainBox, BorderLayout.CENTER);
        
        JPanel gapPanel = new JPanel();
        gapPanel.setOpaque(false); // 투명하게
        gapPanel.setPreferredSize(new Dimension(800, 10)); // 10px 간격
        rightPanel.add(gapPanel, BorderLayout.AFTER_LAST_LINE); // 하단에 배치

        // 하단 회색 바 위치
        bottomBox.setPreferredSize(new Dimension(1000, 70));
        bottomBox.setMinimumSize(new Dimension(1000, 70));
        bottomBox.setMaximumSize(new Dimension(1000, 70));
        rightPanel.add(bottomBox, BorderLayout.SOUTH);

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MBTIChat().setVisible(true));
    }

}
