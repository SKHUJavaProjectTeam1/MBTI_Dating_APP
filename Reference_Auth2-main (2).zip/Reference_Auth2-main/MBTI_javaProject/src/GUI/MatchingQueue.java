package GUI;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Arrays;

class UIConstants {
    static final Font TITLE_FONT = new Font("맑은 고딕", Font.BOLD, 20);
    static final Font LABEL_FONT = new Font("맑은 고딕", Font.PLAIN, 13);
    static final Font BUTTON_FONT = new Font("맑은 고딕", Font.BOLD, 14);

    static final Color BACKGROUND = Color.WHITE;
    static final Color FINDING_BG = new Color(220, 255, 250);
    static final Color FRIEND_BG = new Color(255, 210, 210);
    static final Color FRIEND_TITLE_BG = new Color(255, 180, 255);
    static final Color ACCEPT_BTN_BG = new Color(180, 200, 255);
    static final Color REJECT_BTN_BG = new Color(255, 150, 150);
}

// 시계 패널
class ClockPanel extends JLabel {
    public ClockPanel() {
        setHorizontalAlignment(SwingConstants.CENTER);
        setFont(new Font("맑은 고딕", Font.BOLD, 25));
        updateTime();
        Timer timer = new Timer(1000, e -> updateTime());
        timer.start();
    }

    private void updateTime() {
        setText(new SimpleDateFormat("HH:mm").format(new Date()));
    }
}

// 친구 요청 패널
class FriendRequestPanel extends JPanel {
    private List<String> requests;
    private JPanel requestListPanel;
    private JButton moreBtn;
    private int shownCount = 3;

    public FriendRequestPanel(List<String> requests) {
        this.requests = requests;
        setLayout(new BorderLayout());
        setBackground(UIConstants.FRIEND_BG);

        JLabel title = new JLabel("친구 요청", SwingConstants.CENTER);
        title.setOpaque(true);
        title.setBackground(UIConstants.FRIEND_TITLE_BG);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 20));
        title.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));

        requestListPanel = new JPanel();
        requestListPanel.setLayout(new BoxLayout(requestListPanel, BoxLayout.Y_AXIS));
        requestListPanel.setBackground(UIConstants.FRIEND_BG);

        JScrollPane scrollPane = new JScrollPane(requestListPanel);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(UIConstants.FRIEND_BG);
        scrollPane.setPreferredSize(new Dimension(180, 180));

        moreBtn = new JButton("▼");
        moreBtn.setBackground(new Color(230, 200, 255));
        moreBtn.setFocusPainted(false);
        moreBtn.addActionListener(e -> showMoreRequests());

        add(title, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(moreBtn, BorderLayout.SOUTH);

        updateRequestList();
    }

    private void updateRequestList() {
        requestListPanel.removeAll();

        if (requests == null || requests.isEmpty()) {
            JLabel empty = new JLabel("(비어 있음)", SwingConstants.CENTER);
            empty.setFont(UIConstants.LABEL_FONT);
            empty.setForeground(Color.DARK_GRAY);
            requestListPanel.add(empty);
        } else {
            int count = Math.min(shownCount, requests.size());
            for (int i = 0; i < count; i++) {
                JLabel nameLabel = new JLabel(requests.get(i) + " 님");
                nameLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 20));
                nameLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 3, 5));
                requestListPanel.add(nameLabel);
            }
        }
        
        if (requests == null || requests.size() <= 3 || shownCount >= requests.size()) {
            moreBtn.setVisible(false);
        } else {
            moreBtn.setVisible(true);
        }

        requestListPanel.revalidate();
        requestListPanel.repaint();
    }

    private void showMoreRequests() {
        if (requests != null && shownCount < requests.size()) {
            shownCount = Math.min(shownCount + 3, requests.size());
            updateRequestList();
        }
    }
}

// 매칭 성공 패널
class MatchSuccessPanel extends JPanel {
	private JLabel matchLabel;
    private JLabel partnerLabel;
    private JButton acceptBtn;
    private JButton rejectBtn;
	
    public MatchSuccessPanel(String matchedName,Runnable onAccept, Runnable onReject) {
        setLayout(null);
        setBackground(UIConstants.BACKGROUND);

        matchLabel = new JLabel("매칭 성공", SwingConstants.CENTER);
        matchLabel.setFont(new Font("맑은 고딕", Font.BOLD, 26));

        partnerLabel = new JLabel("상대(" + matchedName + "님)과 만나시겠습니까?", SwingConstants.CENTER);
        partnerLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 14));

        acceptBtn = new JButton("수락");
        rejectBtn = new JButton("거절");
        acceptBtn.setFont(UIConstants.BUTTON_FONT);
        rejectBtn.setFont(UIConstants.BUTTON_FONT);
        acceptBtn.setBackground(UIConstants.ACCEPT_BTN_BG);
        rejectBtn.setBackground(UIConstants.REJECT_BTN_BG);

        acceptBtn.setOpaque(true);
        acceptBtn.setBorderPainted(false);
        acceptBtn.setFocusPainted(false);

        rejectBtn.setOpaque(true);
        rejectBtn.setBorderPainted(false);
        rejectBtn.setFocusPainted(false);
        
        acceptBtn.addActionListener(e -> {
            new MBTIChat().setVisible(true);
            SwingUtilities.getWindowAncestor(this).dispose();
        });

        rejectBtn.addActionListener(e -> switchToMatching());

        add(matchLabel);
        add(partnerLabel);
        add(acceptBtn);
        add(rejectBtn);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int w = getWidth();
                int h = getHeight();
                int centerX = w / 2;
                int centerY = h / 2;
                matchLabel.setBounds(centerX - 100, centerY - 60, 200, 30);
                partnerLabel.setBounds(centerX - 150, centerY - 25, 300, 25);
                int btnW = 90, btnH = 35;
                acceptBtn.setBounds(centerX - btnW - 10, centerY + 35, btnW, btnH);
                rejectBtn.setBounds(centerX + 10, centerY + 35, btnW, btnH);
            }
        });
    }
    
    private void switchToMatching() {
        // 기존 버튼, 라벨 제거
        remove(acceptBtn);
        remove(rejectBtn);
        remove(matchLabel);
        remove(partnerLabel);

        // 매칭중 문구 추가
        JLabel waitingLabel = new JLabel("매칭중...", SwingConstants.CENTER);
        waitingLabel.setFont(new Font("맑은 고딕", Font.BOLD, 26));
        waitingLabel.setBounds(0, getHeight()/2 - 20, getWidth(), 40);
        waitingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(waitingLabel);

        revalidate();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int size = Math.min(getWidth(), getHeight()) - 160;
        int x = (getWidth() - size) / 2;
        int y = (getHeight() - size) / 2;

        GradientPaint gradient = new GradientPaint(x, y, new Color(180, 255, 240),
                                                   x + size, y + size, new Color(255, 180, 180));
        g2.setStroke(new BasicStroke(20f));
        g2.setPaint(gradient);
        g2.drawOval(x, y, size, size);
    }
}

// 메인 프레임
public class MatchingQueue extends JFrame {
    public MatchingQueue(String userName, String matchedName, boolean matchSuccess, List<String> requests) {
        setTitle("매칭 대기열");
        setSize(750, 540);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UIConstants.BACKGROUND);

        // 왼쪽
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(UIConstants.BACKGROUND);
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel findingLabel = new JLabel("상대를 찾는 중", SwingConstants.CENTER);
        findingLabel.setFont(UIConstants.TITLE_FONT);
        findingLabel.setOpaque(true);
        findingLabel.setBackground(UIConstants.FINDING_BG);
        findingLabel.setBorder(BorderFactory.createLineBorder(new Color(150, 200, 200), 2));

        JPanel findingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        findingPanel.setOpaque(false);
        findingPanel.add(findingLabel);

        leftPanel.add(findingPanel, BorderLayout.NORTH);
        if (matchSuccess) {
        	leftPanel.add(new MatchSuccessPanel(matchedName,
        	        () -> { // 수락 버튼 클릭 → MBTIChat 화면
        	            leftPanel.removeAll();
        	            leftPanel.add(new MBTIChat(), BorderLayout.CENTER);
        	            leftPanel.revalidate();
        	            leftPanel.repaint();
        	        },null
        	        ),BorderLayout.CENTER);
        }

        // 오른쪽
        JPanel rightPanel = new JPanel();
        rightPanel.setPreferredSize(new Dimension(200, 0));
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(UIConstants.FRIEND_BG);

        JLabel userLabel = new JLabel(userName + " 님", SwingConstants.CENTER);
        userLabel.setFont(new Font("맑은 고딕", Font.BOLD, 15));
        userLabel.setBorder(BorderFactory.createEmptyBorder(15, 5, 5, 5));
        userLabel.setBackground(UIConstants.FRIEND_BG);
        userLabel.setOpaque(true);
        userLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        ClockPanel clock = new ClockPanel();
        clock.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        clock.setBackground(UIConstants.FRIEND_BG);
        clock.setOpaque(true);
        clock.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 친구 요청 패널
        FriendRequestPanel friendPanel = new FriendRequestPanel(requests);
        friendPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        friendPanel.setMaximumSize(new Dimension(200, 250));

        rightPanel.add(userLabel);
        rightPanel.add(clock);
        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(friendPanel);

        add(leftPanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        List<String> requests = Arrays.asList("홍길동", "김영희", "박철수", "이민수", "최지현");
        new MatchingQueue("사용자", "상대방", true, requests);
    }
}