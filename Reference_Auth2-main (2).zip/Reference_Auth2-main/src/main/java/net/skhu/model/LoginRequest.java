package net.skhu.model;

import lombok.Data;

@Data
public class LoginRequest {
    private String userName;
    private String pwd;
}
