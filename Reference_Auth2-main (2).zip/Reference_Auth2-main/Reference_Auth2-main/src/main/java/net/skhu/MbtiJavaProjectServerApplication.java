package net.skhu;

import net.skhu.gui.MBTILoginSignup;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

import javax.swing.*;

@SpringBootApplication
public class MbtiJavaProjectServerApplication {

    public static void main(String[] args) {
        // Swing GUI를 띄우기 위해 headless 모드 해제
        System.setProperty("java.awt.headless", "false");

        // Spring Boot 서버 시작
        SpringApplication.run(MbtiJavaProjectServerApplication.class, args);
    }

    // 서버가 완전히 켜진 뒤 GUI 실행
    @EventListener(ApplicationReadyEvent.class)
    public void openMainWindow() {
        SwingUtilities.invokeLater(() -> {
            try {
                new MBTILoginSignup().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

}
