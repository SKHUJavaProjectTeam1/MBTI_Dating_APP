package GUI;

import javax.swing.*;
import java.awt.*;

public class ChatList extends JFrame{
	
	private String[] person = {"aa","bb","cc"};
	
	 public ChatList() {
	        setTitle("채팅 리스트");
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setSize(250, 500);
	        setLayout(new BorderLayout());
	        getContentPane().setBackground(new Color(255, 200, 200));

	        // 상단 제목
	        JLabel title = new JLabel("채팅 리스트", SwingConstants.CENTER);
	        title.setFont(new Font("맑은 고딕", Font.BOLD, 20));
	        title.setForeground(Color.BLACK);
	        title.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
	        add(title, BorderLayout.NORTH);

	        // 스크롤 영역
	        JPanel chatPanel = new JPanel();
	        chatPanel.setBackground(new Color(200, 255, 255));
	        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
	        chatPanel.add(Box.createVerticalStrut(10));

	        //채팅방 3개 생성
	        for (String p : person) {
	            chatPanel.add(makeChatRoomPanel(p));
	            chatPanel.add(Box.createVerticalStrut(10));
	        }

	        JScrollPane scrollPane = new JScrollPane(chatPanel);
	        scrollPane.setBorder(BorderFactory.createEmptyBorder());
	        scrollPane.getVerticalScrollBar().setUnitIncrement(10);
	        add(scrollPane, BorderLayout.CENTER);

	        // 닫기 버튼
	        JButton closeBtn = new JButton("닫기");
	        closeBtn.addActionListener(e -> System.exit(0)); // 프로세스 종료
	        
	        JPanel closePanel = new JPanel();
	        closePanel.setBackground(new Color(255, 200, 200));
	        closePanel.add(closeBtn);
	        add(closePanel, BorderLayout.SOUTH);

	        setVisible(true);
	    }

	    private JPanel makeChatRoomPanel(String name) {
	    	// 회색 카드 패널
	        JPanel roomPanel = new JPanel();
	        roomPanel.setLayout(new BorderLayout(5, 5));
	        roomPanel.setPreferredSize(new Dimension(180, 40));
	        roomPanel.setMaximumSize(new Dimension(180, 40));
	        roomPanel.setBackground(new Color(230, 230, 230));
	        roomPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1));

	        //회색 안의 글씨(채팅방 제목)
	        JLabel label = new JLabel(name + " 님");
	        label.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
	        
	        //각 채팅방의 입장 버튼 외형
	        JButton enterBtn = new JButton("입장");
	        enterBtn.setBackground(Color.MAGENTA);
	        enterBtn.setForeground(Color.WHITE);

	        //"입장" 버튼 클릭 시 실행할 동작
	        enterBtn.addActionListener(e -> {
	        	new MBTIChat().setVisible(true);
	        	ChatList.this.dispose();
	        	});
	        
	        //버튼 여백주는 부분
	        JPanel btnPanel = new JPanel(new BorderLayout());
	        btnPanel.setBackground(new Color(230, 230, 230));
	        btnPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 8));
	        btnPanel.add(enterBtn, BorderLayout.CENTER);

	        roomPanel.add(label, BorderLayout.WEST);
	        roomPanel.add(enterBtn, BorderLayout.EAST);
	        return roomPanel;
	    }

	public static void main(String[] args) {
		new ChatList();
	}

}
